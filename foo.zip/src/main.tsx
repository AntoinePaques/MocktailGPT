import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

async function prepare() {
  if (import.meta.env.MODE === 'development') {
    // Démarre MSW seulement en dev
    const { worker } = await import('./api/generated/msw');
    await worker.start();
  }
}

prepare().then(() => {
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
});
