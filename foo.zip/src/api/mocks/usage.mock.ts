import { faker } from '@faker-js/faker';
import type { ChatCompletionUsage, VanQuery } from '../../api_old/models';

export const mockUsage = (query: VanQuery): ChatCompletionUsage => ({
  id: faker.string.uuid(),
  object: 'chat.completion',
  created: Math.floor(Date.now() / 1000),
  model: 'gpt-4o',
  choices: [
    {
      index: 0,
      finish_reason: 'stop',
      message: {
        role: 'assistant',
        content: {
          maintenance: {
            interval_km: 30000,
            interval_months: 24,
            details: 'Vidange, filtres, freins.',
          },
        },
      },
    },
  ],
});
