import { faker } from '@faker-js/faker';
import type { ChatCompletionTips, VanQuery } from '../../api_old/models';

export const mockTips = (query: VanQuery): ChatCompletionTips => ({
  id: faker.string.uuid(),
  object: 'chat.completion',
  created: Math.floor(Date.now() / 1000),
  model: 'gpt-4o',
  choices: [
    {
      index: 0,
      finish_reason: 'stop',
      message: {
        role: 'assistant',
        content: {
          tips: [
            'Vérifiez la législation belge.',
            'Ventilez correctement.',
            'Électricité certifiée.',
          ],
        },
      },
    },
  ],
});
