import { faker } from '@faker-js/faker';
import type { ChatCompletionDocs, VanQuery } from '../../api_old/models';

export const mockDocs = (query: VanQuery): ChatCompletionDocs => ({
  id: faker.string.uuid(),
  object: 'chat.completion',
  created: Math.floor(Date.now() / 1000),
  model: 'gpt-4o',
  choices: [
    {
      index: 0,
      finish_reason: 'stop',
      message: {
        role: 'assistant',
        content: {
          docs: [
            'https://docs.vanscrapper.com/boxer-2017-manual.pdf',
            'https://youtube.com/van_conversion_guide',
          ],
        },
      },
    },
  ],
});
