import { faker } from '@faker-js/faker';
import type { ChatCompletionError, VanQuery } from '../../api_old/models';

export const mockError = (query: VanQuery): ChatCompletionError => ({
  id: faker.string.uuid(),
  object: 'chat.completion',
  created: Math.floor(Date.now() / 1000),
  model: 'gpt-4o',
  choices: [
    {
      index: 0,
      finish_reason: 'stop',
      message: {
        role: 'assistant',
        content: {
          status: 'error',
          message: 'Invalid van parameters.',
          request_id: faker.string.uuid(),
        },
      },
    },
  ],
});
