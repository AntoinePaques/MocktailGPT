import { faker } from '@faker-js/faker';
import type { ChatCompletionAll, VanQuery } from '../../api_old/models';

export const mockAll = (query: VanQuery): ChatCompletionAll => ({
  id: faker.string.uuid(),
  object: 'chat.completion',
  created: Math.floor(Date.now() / 1000),
  model: 'gpt-4o',
  choices: [
    {
      index: 0,
      finish_reason: 'stop',
      message: {
        role: 'assistant',
        content: {
          query: {
            brand: 'Peugeot',
            model: 'Boxer',
            year: 2017,
            size: 'L2H2',
            engine: '2.2 HDi 130',
            slug: 'peugeot-boxer-2017-l2h2',
          },
          specs: {
            dimensions: { length_mm: 5998, width_mm: 2050, height_mm: 2520, wheelbase_mm: 4035 },
            structure: { frame_type: 'monocoque', chassis: 'standard' },
            mechanics: { fuel: 'diesel', power_hp: 140, euro_norm: 'Euro 6d' },
            layouts: { seat_count: 3, bed_count: 2 },
            schematics: { electrical: 'electrical.pdf', plumbing: 'plumbing.pdf' },
            features: ['AC', 'cruise'],
            compatibility: ['L2H2', 'L3H2'],
            notes: 'Van conversion friendly.',
            deprecated: false,
            resale_difficulty: 'moyenne',
          },
          market: {
            price_buy: 12000,
            price_sell: 18500,
            resale_difficulty: 'facile',
          },
          usage: {
            maintenance: {
              interval_km: 30000,
              interval_months: 24,
              details: 'Vidange, filtres, freins.',
            },
          },
          tips: {
            tips: ['Vérifiez la législation belge.', 'Ventilez correctement.'],
          },
          history: {
            history: ['2017: restylage, nouveaux moteurs.'],
          },
          docs: {
            docs: [
              'https://docs.vanscrapper.com/boxer-2017-manual.pdf',
              'https://youtube.com/van_conversion_guide',
            ],
          },
        },
      },
    },
  ],
});
