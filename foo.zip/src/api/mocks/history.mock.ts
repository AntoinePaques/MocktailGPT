import { faker } from '@faker-js/faker';
import type { ChatCompletionHistory, VanQuery } from '../../api_old/models';

export const mockHistory = (query: VanQuery): ChatCompletionHistory => ({
  id: faker.string.uuid(),
  object: 'chat.completion',
  created: Math.floor(Date.now() / 1000),
  model: 'gpt-4o',
  choices: [
    {
      index: 0,
      finish_reason: 'stop',
      message: {
        role: 'assistant',
        content: {
          history: ['2017: restylage, nouveaux moteurs.', '2020: habitacle upgradé.'],
        },
      },
    },
  ],
});
