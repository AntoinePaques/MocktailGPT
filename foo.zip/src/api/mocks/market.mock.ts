import { faker } from '@faker-js/faker';
import type { ChatCompletionMarket, VanQuery } from '../../api_old/models';

export const mockMarket = (query: VanQuery): ChatCompletionMarket => ({
  id: faker.string.uuid(),
  object: 'chat.completion',
  created: Math.floor(Date.now() / 1000),
  model: 'gpt-4o',
  choices: [
    {
      index: 0,
      finish_reason: 'stop',
      message: {
        role: 'assistant',
        content: {
          price_buy: 12000,
          price_sell: 18500,
          resale_difficulty: 'facile',
        },
      },
    },
  ],
});
